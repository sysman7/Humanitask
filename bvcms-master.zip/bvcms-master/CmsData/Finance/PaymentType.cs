﻿namespace CmsData.Finance
{
    public static class PaymentType
    {
        public const string CreditCard = "C";
        public const string Ach = "B";
    }
}