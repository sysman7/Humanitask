﻿
namespace CmsData.Finance.TransNational.Query
{
    internal enum TransactionType
    {
        Unknown,
        CreditCard,
        Ach,
    }
}
