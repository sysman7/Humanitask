﻿
namespace CmsData.Finance.TransNational.Query
{
    internal enum Condition
    {
        Pending,
        PendingSettlement,
        Failed,
        Canceled,
        Complete,
        Unknown
    }
}
