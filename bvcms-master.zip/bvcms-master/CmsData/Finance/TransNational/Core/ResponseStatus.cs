﻿namespace CmsData.Finance.TransNational.Core
{
    public enum ResponseStatus
    {
        Approved = 1,
        Declined = 2,
        SystemError = 3
    }
}
