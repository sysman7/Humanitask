﻿namespace CmsData.Finance
{
    public enum TransactionType
    {
        Unknown,
        Charge,
        Credit,
        Refund
    }
}