﻿namespace CmsData.Finance
{
    public enum BatchType
    {
        Unknown,
        CreditCard,
        Ach
    }
}