﻿
namespace CmsData.Finance.Sage.Core
{
    internal enum ApprovalIndicator
    {
        NotSet = 0,
        Approved = 1,
        FrontEndError = 2,
        GatewayError = 3
    }
}
