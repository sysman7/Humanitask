﻿
namespace CmsData.Finance.Sage.Report
{
    internal enum BatchType
    {
        Unknown,
        CreditCard,
        Ach
    }
}
