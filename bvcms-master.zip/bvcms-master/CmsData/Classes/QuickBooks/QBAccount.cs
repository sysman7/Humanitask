﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CmsData.Classes.QuickBooks
{
    public class QBAccount
    {
        public string ID { get; set; }
        public string Name { get; set; }
    }
}
