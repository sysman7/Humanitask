﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CmsData.Classes.GoogleCloudMessaging
{
    public class GCMResponseResult
    {
        public string message_id = "";
        public string registration_id = "";
        public string error = "";
    }
}
