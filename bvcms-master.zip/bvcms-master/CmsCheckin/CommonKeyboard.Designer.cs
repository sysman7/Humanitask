﻿namespace CmsCheckin
{
	partial class CommonKeyboard
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.brbrace = new System.Windows.Forms.Button();
			this.blbrace = new System.Windows.Forms.Button();
			this.bequal = new System.Windows.Forms.Button();
			this.bdash = new System.Windows.Forms.Button();
			this.bcomma = new System.Windows.Forms.Button();
			this.bshift = new System.Windows.Forms.Button();
			this.bcolon = new System.Windows.Forms.Button();
			this.bslash = new System.Windows.Forms.Button();
			this.bdot = new System.Windows.Forms.Button();
			this.b0 = new System.Windows.Forms.Button();
			this.b1 = new System.Windows.Forms.Button();
			this.b2 = new System.Windows.Forms.Button();
			this.b3 = new System.Windows.Forms.Button();
			this.b4 = new System.Windows.Forms.Button();
			this.b5 = new System.Windows.Forms.Button();
			this.b6 = new System.Windows.Forms.Button();
			this.b7 = new System.Windows.Forms.Button();
			this.b9 = new System.Windows.Forms.Button();
			this.b8 = new System.Windows.Forms.Button();
			this.bm = new System.Windows.Forms.Button();
			this.bn = new System.Windows.Forms.Button();
			this.bb = new System.Windows.Forms.Button();
			this.bv = new System.Windows.Forms.Button();
			this.bc = new System.Windows.Forms.Button();
			this.bx = new System.Windows.Forms.Button();
			this.bz = new System.Windows.Forms.Button();
			this.ba = new System.Windows.Forms.Button();
			this.bs = new System.Windows.Forms.Button();
			this.bd = new System.Windows.Forms.Button();
			this.bf = new System.Windows.Forms.Button();
			this.bg = new System.Windows.Forms.Button();
			this.bh = new System.Windows.Forms.Button();
			this.bj = new System.Windows.Forms.Button();
			this.bl = new System.Windows.Forms.Button();
			this.bk = new System.Windows.Forms.Button();
			this.bp = new System.Windows.Forms.Button();
			this.bq = new System.Windows.Forms.Button();
			this.bbs = new System.Windows.Forms.Button();
			this.bw = new System.Windows.Forms.Button();
			this.be = new System.Windows.Forms.Button();
			this.br = new System.Windows.Forms.Button();
			this.bt = new System.Windows.Forms.Button();
			this.by = new System.Windows.Forms.Button();
			this.bu = new System.Windows.Forms.Button();
			this.bo = new System.Windows.Forms.Button();
			this.bi = new System.Windows.Forms.Button();
			this.brshift = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// brbrace
			// 
			this.brbrace.BackColor = System.Drawing.SystemColors.ControlLight;
			this.brbrace.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.brbrace.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.brbrace.Location = new System.Drawing.Point(680, 70);
			this.brbrace.Margin = new System.Windows.Forms.Padding(4);
			this.brbrace.Name = "brbrace";
			this.brbrace.Size = new System.Drawing.Size(47, 49);
			this.brbrace.TabIndex = 177;
			this.brbrace.TabStop = false;
			this.brbrace.Text = "]";
			this.brbrace.UseVisualStyleBackColor = false;
			// 
			// blbrace
			// 
			this.blbrace.BackColor = System.Drawing.SystemColors.ControlLight;
			this.blbrace.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.blbrace.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.blbrace.Location = new System.Drawing.Point(625, 70);
			this.blbrace.Margin = new System.Windows.Forms.Padding(4);
			this.blbrace.Name = "blbrace";
			this.blbrace.Size = new System.Drawing.Size(47, 49);
			this.blbrace.TabIndex = 176;
			this.blbrace.TabStop = false;
			this.blbrace.Text = "[";
			this.blbrace.UseVisualStyleBackColor = false;
			// 
			// bequal
			// 
			this.bequal.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bequal.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bequal.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bequal.Location = new System.Drawing.Point(655, 13);
			this.bequal.Margin = new System.Windows.Forms.Padding(4);
			this.bequal.Name = "bequal";
			this.bequal.Size = new System.Drawing.Size(47, 49);
			this.bequal.TabIndex = 175;
			this.bequal.TabStop = false;
			this.bequal.Text = "=";
			this.bequal.UseVisualStyleBackColor = false;
			// 
			// bdash
			// 
			this.bdash.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bdash.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bdash.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bdash.Location = new System.Drawing.Point(600, 13);
			this.bdash.Margin = new System.Windows.Forms.Padding(4);
			this.bdash.Name = "bdash";
			this.bdash.Size = new System.Drawing.Size(47, 49);
			this.bdash.TabIndex = 174;
			this.bdash.TabStop = false;
			this.bdash.Text = "-";
			this.bdash.UseVisualStyleBackColor = false;
			// 
			// bcomma
			// 
			this.bcomma.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bcomma.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bcomma.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bcomma.Location = new System.Drawing.Point(516, 185);
			this.bcomma.Margin = new System.Windows.Forms.Padding(4);
			this.bcomma.Name = "bcomma";
			this.bcomma.Size = new System.Drawing.Size(47, 49);
			this.bcomma.TabIndex = 173;
			this.bcomma.TabStop = false;
			this.bcomma.Text = ",";
			this.bcomma.UseVisualStyleBackColor = false;
			// 
			// bshift
			// 
			this.bshift.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bshift.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bshift.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bshift.Location = new System.Drawing.Point(25, 187);
			this.bshift.Margin = new System.Windows.Forms.Padding(4);
			this.bshift.Name = "bshift";
			this.bshift.Size = new System.Drawing.Size(81, 47);
			this.bshift.TabIndex = 172;
			this.bshift.TabStop = false;
			this.bshift.Text = "Shift";
			this.bshift.UseVisualStyleBackColor = false;
			// 
			// bcolon
			// 
			this.bcolon.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bcolon.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bcolon.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bcolon.Location = new System.Drawing.Point(603, 127);
			this.bcolon.Margin = new System.Windows.Forms.Padding(4);
			this.bcolon.Name = "bcolon";
			this.bcolon.Size = new System.Drawing.Size(47, 50);
			this.bcolon.TabIndex = 171;
			this.bcolon.TabStop = false;
			this.bcolon.Text = ";";
			this.bcolon.UseVisualStyleBackColor = false;
			// 
			// bslash
			// 
			this.bslash.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bslash.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bslash.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bslash.Location = new System.Drawing.Point(626, 185);
			this.bslash.Margin = new System.Windows.Forms.Padding(4);
			this.bslash.Name = "bslash";
			this.bslash.Size = new System.Drawing.Size(47, 49);
			this.bslash.TabIndex = 170;
			this.bslash.TabStop = false;
			this.bslash.Text = "/";
			this.bslash.UseVisualStyleBackColor = false;
			// 
			// bdot
			// 
			this.bdot.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bdot.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bdot.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bdot.Location = new System.Drawing.Point(571, 185);
			this.bdot.Margin = new System.Windows.Forms.Padding(4);
			this.bdot.Name = "bdot";
			this.bdot.Size = new System.Drawing.Size(47, 49);
			this.bdot.TabIndex = 169;
			this.bdot.TabStop = false;
			this.bdot.Text = ".";
			this.bdot.UseVisualStyleBackColor = false;
			// 
			// b0
			// 
			this.b0.BackColor = System.Drawing.SystemColors.ControlLight;
			this.b0.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.b0.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.b0.Location = new System.Drawing.Point(545, 13);
			this.b0.Margin = new System.Windows.Forms.Padding(4);
			this.b0.Name = "b0";
			this.b0.Size = new System.Drawing.Size(47, 49);
			this.b0.TabIndex = 168;
			this.b0.TabStop = false;
			this.b0.Text = "0";
			this.b0.UseVisualStyleBackColor = false;
			// 
			// b1
			// 
			this.b1.BackColor = System.Drawing.SystemColors.ControlLight;
			this.b1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.b1.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.b1.Location = new System.Drawing.Point(32, 13);
			this.b1.Margin = new System.Windows.Forms.Padding(4);
			this.b1.Name = "b1";
			this.b1.Size = new System.Drawing.Size(47, 49);
			this.b1.TabIndex = 159;
			this.b1.TabStop = false;
			this.b1.Text = "1";
			this.b1.UseVisualStyleBackColor = false;
			// 
			// b2
			// 
			this.b2.BackColor = System.Drawing.SystemColors.ControlLight;
			this.b2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.b2.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.b2.Location = new System.Drawing.Point(89, 13);
			this.b2.Margin = new System.Windows.Forms.Padding(4);
			this.b2.Name = "b2";
			this.b2.Size = new System.Drawing.Size(47, 49);
			this.b2.TabIndex = 160;
			this.b2.TabStop = false;
			this.b2.Text = "2";
			this.b2.UseVisualStyleBackColor = false;
			// 
			// b3
			// 
			this.b3.BackColor = System.Drawing.SystemColors.ControlLight;
			this.b3.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.b3.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.b3.Location = new System.Drawing.Point(146, 13);
			this.b3.Margin = new System.Windows.Forms.Padding(4);
			this.b3.Name = "b3";
			this.b3.Size = new System.Drawing.Size(47, 49);
			this.b3.TabIndex = 161;
			this.b3.TabStop = false;
			this.b3.Text = "3";
			this.b3.UseVisualStyleBackColor = false;
			// 
			// b4
			// 
			this.b4.BackColor = System.Drawing.SystemColors.ControlLight;
			this.b4.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.b4.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.b4.Location = new System.Drawing.Point(203, 13);
			this.b4.Margin = new System.Windows.Forms.Padding(4);
			this.b4.Name = "b4";
			this.b4.Size = new System.Drawing.Size(47, 49);
			this.b4.TabIndex = 162;
			this.b4.TabStop = false;
			this.b4.Text = "4";
			this.b4.UseVisualStyleBackColor = false;
			// 
			// b5
			// 
			this.b5.BackColor = System.Drawing.SystemColors.ControlLight;
			this.b5.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.b5.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.b5.Location = new System.Drawing.Point(260, 13);
			this.b5.Margin = new System.Windows.Forms.Padding(4);
			this.b5.Name = "b5";
			this.b5.Size = new System.Drawing.Size(47, 49);
			this.b5.TabIndex = 163;
			this.b5.TabStop = false;
			this.b5.Text = "5";
			this.b5.UseVisualStyleBackColor = false;
			// 
			// b6
			// 
			this.b6.BackColor = System.Drawing.SystemColors.ControlLight;
			this.b6.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.b6.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.b6.Location = new System.Drawing.Point(317, 13);
			this.b6.Margin = new System.Windows.Forms.Padding(4);
			this.b6.Name = "b6";
			this.b6.Size = new System.Drawing.Size(47, 49);
			this.b6.TabIndex = 164;
			this.b6.TabStop = false;
			this.b6.Text = "6";
			this.b6.UseVisualStyleBackColor = false;
			// 
			// b7
			// 
			this.b7.BackColor = System.Drawing.SystemColors.ControlLight;
			this.b7.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.b7.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.b7.Location = new System.Drawing.Point(374, 13);
			this.b7.Margin = new System.Windows.Forms.Padding(4);
			this.b7.Name = "b7";
			this.b7.Size = new System.Drawing.Size(47, 49);
			this.b7.TabIndex = 165;
			this.b7.TabStop = false;
			this.b7.Text = "7";
			this.b7.UseVisualStyleBackColor = false;
			// 
			// b9
			// 
			this.b9.BackColor = System.Drawing.SystemColors.ControlLight;
			this.b9.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.b9.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.b9.Location = new System.Drawing.Point(488, 13);
			this.b9.Margin = new System.Windows.Forms.Padding(4);
			this.b9.Name = "b9";
			this.b9.Size = new System.Drawing.Size(47, 49);
			this.b9.TabIndex = 167;
			this.b9.TabStop = false;
			this.b9.Text = "9";
			this.b9.UseVisualStyleBackColor = false;
			// 
			// b8
			// 
			this.b8.BackColor = System.Drawing.SystemColors.ControlLight;
			this.b8.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.b8.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.b8.Location = new System.Drawing.Point(431, 13);
			this.b8.Margin = new System.Windows.Forms.Padding(4);
			this.b8.Name = "b8";
			this.b8.Size = new System.Drawing.Size(47, 49);
			this.b8.TabIndex = 166;
			this.b8.TabStop = false;
			this.b8.Text = "8";
			this.b8.UseVisualStyleBackColor = false;
			// 
			// bm
			// 
			this.bm.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bm.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bm.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bm.Location = new System.Drawing.Point(461, 185);
			this.bm.Margin = new System.Windows.Forms.Padding(4);
			this.bm.Name = "bm";
			this.bm.Size = new System.Drawing.Size(47, 49);
			this.bm.TabIndex = 158;
			this.bm.TabStop = false;
			this.bm.Text = "m";
			this.bm.UseVisualStyleBackColor = false;
			// 
			// bn
			// 
			this.bn.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bn.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bn.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bn.Location = new System.Drawing.Point(404, 185);
			this.bn.Margin = new System.Windows.Forms.Padding(4);
			this.bn.Name = "bn";
			this.bn.Size = new System.Drawing.Size(47, 49);
			this.bn.TabIndex = 157;
			this.bn.TabStop = false;
			this.bn.Text = "n";
			this.bn.UseVisualStyleBackColor = false;
			// 
			// bb
			// 
			this.bb.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bb.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bb.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bb.Location = new System.Drawing.Point(347, 185);
			this.bb.Margin = new System.Windows.Forms.Padding(4);
			this.bb.Name = "bb";
			this.bb.Size = new System.Drawing.Size(47, 49);
			this.bb.TabIndex = 156;
			this.bb.TabStop = false;
			this.bb.Text = "b";
			this.bb.UseVisualStyleBackColor = false;
			// 
			// bv
			// 
			this.bv.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bv.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bv.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bv.Location = new System.Drawing.Point(290, 185);
			this.bv.Margin = new System.Windows.Forms.Padding(4);
			this.bv.Name = "bv";
			this.bv.Size = new System.Drawing.Size(47, 49);
			this.bv.TabIndex = 155;
			this.bv.TabStop = false;
			this.bv.Text = "v";
			this.bv.UseVisualStyleBackColor = false;
			// 
			// bc
			// 
			this.bc.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bc.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bc.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bc.Location = new System.Drawing.Point(233, 185);
			this.bc.Margin = new System.Windows.Forms.Padding(4);
			this.bc.Name = "bc";
			this.bc.Size = new System.Drawing.Size(47, 49);
			this.bc.TabIndex = 154;
			this.bc.TabStop = false;
			this.bc.Text = "c";
			this.bc.UseVisualStyleBackColor = false;
			// 
			// bx
			// 
			this.bx.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bx.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bx.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bx.Location = new System.Drawing.Point(176, 185);
			this.bx.Margin = new System.Windows.Forms.Padding(4);
			this.bx.Name = "bx";
			this.bx.Size = new System.Drawing.Size(47, 49);
			this.bx.TabIndex = 153;
			this.bx.TabStop = false;
			this.bx.Text = "x";
			this.bx.UseVisualStyleBackColor = false;
			// 
			// bz
			// 
			this.bz.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bz.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bz.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bz.Location = new System.Drawing.Point(119, 185);
			this.bz.Margin = new System.Windows.Forms.Padding(4);
			this.bz.Name = "bz";
			this.bz.Size = new System.Drawing.Size(47, 49);
			this.bz.TabIndex = 152;
			this.bz.TabStop = false;
			this.bz.Text = "z";
			this.bz.UseVisualStyleBackColor = false;
			// 
			// ba
			// 
			this.ba.BackColor = System.Drawing.SystemColors.ControlLight;
			this.ba.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.ba.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.ba.Location = new System.Drawing.Point(92, 127);
			this.ba.Margin = new System.Windows.Forms.Padding(4);
			this.ba.Name = "ba";
			this.ba.Size = new System.Drawing.Size(47, 50);
			this.ba.TabIndex = 143;
			this.ba.TabStop = false;
			this.ba.Text = "a";
			this.ba.UseVisualStyleBackColor = false;
			// 
			// bs
			// 
			this.bs.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bs.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bs.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bs.Location = new System.Drawing.Point(149, 127);
			this.bs.Margin = new System.Windows.Forms.Padding(4);
			this.bs.Name = "bs";
			this.bs.Size = new System.Drawing.Size(47, 50);
			this.bs.TabIndex = 144;
			this.bs.TabStop = false;
			this.bs.Text = "s";
			this.bs.UseVisualStyleBackColor = false;
			// 
			// bd
			// 
			this.bd.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bd.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bd.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bd.Location = new System.Drawing.Point(206, 127);
			this.bd.Margin = new System.Windows.Forms.Padding(4);
			this.bd.Name = "bd";
			this.bd.Size = new System.Drawing.Size(47, 50);
			this.bd.TabIndex = 145;
			this.bd.TabStop = false;
			this.bd.Text = "d";
			this.bd.UseVisualStyleBackColor = false;
			// 
			// bf
			// 
			this.bf.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bf.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bf.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bf.Location = new System.Drawing.Point(263, 127);
			this.bf.Margin = new System.Windows.Forms.Padding(4);
			this.bf.Name = "bf";
			this.bf.Size = new System.Drawing.Size(47, 50);
			this.bf.TabIndex = 146;
			this.bf.TabStop = false;
			this.bf.Text = "f";
			this.bf.UseVisualStyleBackColor = false;
			// 
			// bg
			// 
			this.bg.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bg.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bg.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bg.Location = new System.Drawing.Point(320, 127);
			this.bg.Margin = new System.Windows.Forms.Padding(4);
			this.bg.Name = "bg";
			this.bg.Size = new System.Drawing.Size(47, 50);
			this.bg.TabIndex = 147;
			this.bg.TabStop = false;
			this.bg.Text = "g";
			this.bg.UseVisualStyleBackColor = false;
			// 
			// bh
			// 
			this.bh.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bh.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bh.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bh.Location = new System.Drawing.Point(377, 127);
			this.bh.Margin = new System.Windows.Forms.Padding(4);
			this.bh.Name = "bh";
			this.bh.Size = new System.Drawing.Size(47, 50);
			this.bh.TabIndex = 148;
			this.bh.TabStop = false;
			this.bh.Text = "h";
			this.bh.UseVisualStyleBackColor = false;
			// 
			// bj
			// 
			this.bj.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bj.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bj.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bj.Location = new System.Drawing.Point(434, 127);
			this.bj.Margin = new System.Windows.Forms.Padding(4);
			this.bj.Name = "bj";
			this.bj.Size = new System.Drawing.Size(47, 50);
			this.bj.TabIndex = 149;
			this.bj.TabStop = false;
			this.bj.Text = "j";
			this.bj.UseVisualStyleBackColor = false;
			// 
			// bl
			// 
			this.bl.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bl.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bl.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bl.Location = new System.Drawing.Point(548, 127);
			this.bl.Margin = new System.Windows.Forms.Padding(4);
			this.bl.Name = "bl";
			this.bl.Size = new System.Drawing.Size(47, 50);
			this.bl.TabIndex = 151;
			this.bl.TabStop = false;
			this.bl.Text = "l";
			this.bl.UseVisualStyleBackColor = false;
			// 
			// bk
			// 
			this.bk.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bk.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bk.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bk.Location = new System.Drawing.Point(491, 127);
			this.bk.Margin = new System.Windows.Forms.Padding(4);
			this.bk.Name = "bk";
			this.bk.Size = new System.Drawing.Size(47, 50);
			this.bk.TabIndex = 150;
			this.bk.TabStop = false;
			this.bk.Text = "k";
			this.bk.UseVisualStyleBackColor = false;
			// 
			// bp
			// 
			this.bp.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bp.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bp.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bp.Location = new System.Drawing.Point(570, 70);
			this.bp.Margin = new System.Windows.Forms.Padding(4);
			this.bp.Name = "bp";
			this.bp.Size = new System.Drawing.Size(47, 49);
			this.bp.TabIndex = 142;
			this.bp.TabStop = false;
			this.bp.Text = "p";
			this.bp.UseVisualStyleBackColor = false;
			// 
			// bq
			// 
			this.bq.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bq.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bq.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bq.Location = new System.Drawing.Point(57, 70);
			this.bq.Margin = new System.Windows.Forms.Padding(4);
			this.bq.Name = "bq";
			this.bq.Size = new System.Drawing.Size(47, 49);
			this.bq.TabIndex = 132;
			this.bq.TabStop = false;
			this.bq.Text = "q";
			this.bq.UseVisualStyleBackColor = false;
			// 
			// bbs
			// 
			this.bbs.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bbs.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bbs.Font = new System.Drawing.Font("Wingdings", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
			this.bbs.Location = new System.Drawing.Point(710, 12);
			this.bbs.Margin = new System.Windows.Forms.Padding(4);
			this.bbs.Name = "bbs";
			this.bbs.Size = new System.Drawing.Size(62, 50);
			this.bbs.TabIndex = 141;
			this.bbs.TabStop = false;
			this.bbs.Text = "Õ";
			this.bbs.UseVisualStyleBackColor = false;
			// 
			// bw
			// 
			this.bw.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bw.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bw.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bw.Location = new System.Drawing.Point(114, 70);
			this.bw.Margin = new System.Windows.Forms.Padding(4);
			this.bw.Name = "bw";
			this.bw.Size = new System.Drawing.Size(47, 49);
			this.bw.TabIndex = 133;
			this.bw.TabStop = false;
			this.bw.Text = "w";
			this.bw.UseVisualStyleBackColor = false;
			// 
			// be
			// 
			this.be.BackColor = System.Drawing.SystemColors.ControlLight;
			this.be.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.be.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.be.Location = new System.Drawing.Point(171, 70);
			this.be.Margin = new System.Windows.Forms.Padding(4);
			this.be.Name = "be";
			this.be.Size = new System.Drawing.Size(47, 49);
			this.be.TabIndex = 134;
			this.be.TabStop = false;
			this.be.Text = "e";
			this.be.UseVisualStyleBackColor = false;
			// 
			// br
			// 
			this.br.BackColor = System.Drawing.SystemColors.ControlLight;
			this.br.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.br.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.br.Location = new System.Drawing.Point(228, 70);
			this.br.Margin = new System.Windows.Forms.Padding(4);
			this.br.Name = "br";
			this.br.Size = new System.Drawing.Size(47, 49);
			this.br.TabIndex = 135;
			this.br.TabStop = false;
			this.br.Text = "r";
			this.br.UseVisualStyleBackColor = false;
			// 
			// bt
			// 
			this.bt.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bt.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bt.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bt.Location = new System.Drawing.Point(285, 70);
			this.bt.Margin = new System.Windows.Forms.Padding(4);
			this.bt.Name = "bt";
			this.bt.Size = new System.Drawing.Size(47, 49);
			this.bt.TabIndex = 136;
			this.bt.TabStop = false;
			this.bt.Text = "t";
			this.bt.UseVisualStyleBackColor = false;
			// 
			// by
			// 
			this.by.BackColor = System.Drawing.SystemColors.ControlLight;
			this.by.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.by.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.by.Location = new System.Drawing.Point(342, 70);
			this.by.Margin = new System.Windows.Forms.Padding(4);
			this.by.Name = "by";
			this.by.Size = new System.Drawing.Size(47, 49);
			this.by.TabIndex = 137;
			this.by.TabStop = false;
			this.by.Text = "y";
			this.by.UseVisualStyleBackColor = false;
			// 
			// bu
			// 
			this.bu.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bu.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bu.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bu.Location = new System.Drawing.Point(399, 70);
			this.bu.Margin = new System.Windows.Forms.Padding(4);
			this.bu.Name = "bu";
			this.bu.Size = new System.Drawing.Size(47, 49);
			this.bu.TabIndex = 138;
			this.bu.TabStop = false;
			this.bu.Text = "u";
			this.bu.UseVisualStyleBackColor = false;
			// 
			// bo
			// 
			this.bo.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bo.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bo.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bo.Location = new System.Drawing.Point(513, 70);
			this.bo.Margin = new System.Windows.Forms.Padding(4);
			this.bo.Name = "bo";
			this.bo.Size = new System.Drawing.Size(47, 49);
			this.bo.TabIndex = 140;
			this.bo.TabStop = false;
			this.bo.Text = "o";
			this.bo.UseVisualStyleBackColor = false;
			// 
			// bi
			// 
			this.bi.BackColor = System.Drawing.SystemColors.ControlLight;
			this.bi.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.bi.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.bi.Location = new System.Drawing.Point(456, 70);
			this.bi.Margin = new System.Windows.Forms.Padding(4);
			this.bi.Name = "bi";
			this.bi.Size = new System.Drawing.Size(47, 49);
			this.bi.TabIndex = 139;
			this.bi.TabStop = false;
			this.bi.Text = "i";
			this.bi.UseVisualStyleBackColor = false;
			// 
			// brshift
			// 
			this.brshift.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.brshift.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.brshift.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.brshift.Location = new System.Drawing.Point(685, 185);
			this.brshift.Name = "brshift";
			this.brshift.Size = new System.Drawing.Size(81, 49);
			this.brshift.TabIndex = 131;
			this.brshift.Text = "Shift";
			this.brshift.UseVisualStyleBackColor = true;
			// 
			// CommonKeyboard
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(790, 246);
			this.ControlBox = false;
			this.Controls.Add(this.brbrace);
			this.Controls.Add(this.blbrace);
			this.Controls.Add(this.bequal);
			this.Controls.Add(this.bdash);
			this.Controls.Add(this.bcomma);
			this.Controls.Add(this.bshift);
			this.Controls.Add(this.bcolon);
			this.Controls.Add(this.bslash);
			this.Controls.Add(this.bdot);
			this.Controls.Add(this.b0);
			this.Controls.Add(this.b1);
			this.Controls.Add(this.b2);
			this.Controls.Add(this.b3);
			this.Controls.Add(this.b4);
			this.Controls.Add(this.b5);
			this.Controls.Add(this.b6);
			this.Controls.Add(this.b7);
			this.Controls.Add(this.b9);
			this.Controls.Add(this.b8);
			this.Controls.Add(this.bm);
			this.Controls.Add(this.bn);
			this.Controls.Add(this.bb);
			this.Controls.Add(this.bv);
			this.Controls.Add(this.bc);
			this.Controls.Add(this.bx);
			this.Controls.Add(this.bz);
			this.Controls.Add(this.ba);
			this.Controls.Add(this.bs);
			this.Controls.Add(this.bd);
			this.Controls.Add(this.bf);
			this.Controls.Add(this.bg);
			this.Controls.Add(this.bh);
			this.Controls.Add(this.bj);
			this.Controls.Add(this.bl);
			this.Controls.Add(this.bk);
			this.Controls.Add(this.bp);
			this.Controls.Add(this.bq);
			this.Controls.Add(this.bbs);
			this.Controls.Add(this.bw);
			this.Controls.Add(this.be);
			this.Controls.Add(this.br);
			this.Controls.Add(this.bt);
			this.Controls.Add(this.by);
			this.Controls.Add(this.bu);
			this.Controls.Add(this.bo);
			this.Controls.Add(this.bi);
			this.Controls.Add(this.brshift);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "CommonKeyboard";
			this.ShowIcon = false;
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Button brbrace;
		private System.Windows.Forms.Button blbrace;
		private System.Windows.Forms.Button bequal;
		private System.Windows.Forms.Button bdash;
		private System.Windows.Forms.Button bcomma;
		private System.Windows.Forms.Button bshift;
		private System.Windows.Forms.Button bcolon;
		private System.Windows.Forms.Button bslash;
		private System.Windows.Forms.Button bdot;
		private System.Windows.Forms.Button b0;
		private System.Windows.Forms.Button b1;
		private System.Windows.Forms.Button b2;
		private System.Windows.Forms.Button b3;
		private System.Windows.Forms.Button b4;
		private System.Windows.Forms.Button b5;
		private System.Windows.Forms.Button b6;
		private System.Windows.Forms.Button b7;
		private System.Windows.Forms.Button b9;
		private System.Windows.Forms.Button b8;
		private System.Windows.Forms.Button bm;
		private System.Windows.Forms.Button bn;
		private System.Windows.Forms.Button bb;
		private System.Windows.Forms.Button bv;
		private System.Windows.Forms.Button bc;
		private System.Windows.Forms.Button bx;
		private System.Windows.Forms.Button bz;
		private System.Windows.Forms.Button ba;
		private System.Windows.Forms.Button bs;
		private System.Windows.Forms.Button bd;
		private System.Windows.Forms.Button bf;
		private System.Windows.Forms.Button bg;
		private System.Windows.Forms.Button bh;
		private System.Windows.Forms.Button bj;
		private System.Windows.Forms.Button bl;
		private System.Windows.Forms.Button bk;
		private System.Windows.Forms.Button bp;
		private System.Windows.Forms.Button bq;
		private System.Windows.Forms.Button bbs;
		private System.Windows.Forms.Button bw;
		private System.Windows.Forms.Button be;
		private System.Windows.Forms.Button br;
		private System.Windows.Forms.Button bt;
		private System.Windows.Forms.Button by;
		private System.Windows.Forms.Button bu;
		private System.Windows.Forms.Button bo;
		private System.Windows.Forms.Button bi;
		private System.Windows.Forms.Button brshift;
	}
}