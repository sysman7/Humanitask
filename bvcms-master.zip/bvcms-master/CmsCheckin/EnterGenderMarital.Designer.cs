﻿namespace CmsCheckin
{
    partial class EnterGenderMarital
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttongo = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Female = new System.Windows.Forms.RadioButton();
            this.Male = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.widowed = new System.Windows.Forms.RadioButton();
            this.divorced = new System.Windows.Forms.RadioButton();
            this.separated = new System.Windows.Forms.RadioButton();
            this.married = new System.Windows.Forms.RadioButton();
            this.single = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.first = new System.Windows.Forms.Label();
            this.goesby = new System.Windows.Forms.Label();
            this.last = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.Label();
            this.dob = new System.Windows.Forms.Label();
            this.cellphone = new System.Windows.Forms.Label();
            this.homephone = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.addr = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.zip = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.allergies = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.emfriendlab = new System.Windows.Forms.Label();
            this.emphonelab = new System.Windows.Forms.Label();
            this.EmFriend = new System.Windows.Forms.Label();
            this.EmPhone = new System.Windows.Forms.Label();
            this.emergencylab = new System.Windows.Forms.Label();
            this.grade = new System.Windows.Forms.Label();
            this.gradelab = new System.Windows.Forms.Label();
            this.ActiveOther = new System.Windows.Forms.CheckBox();
            this.ParentName = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.churchnameLab = new System.Windows.Forms.Label();
            this.churchname = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttongo
            // 
            this.buttongo.BackColor = System.Drawing.Color.LimeGreen;
            this.buttongo.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.buttongo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttongo.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttongo.ForeColor = System.Drawing.Color.White;
            this.buttongo.Location = new System.Drawing.Point(778, 683);
            this.buttongo.Margin = new System.Windows.Forms.Padding(4);
            this.buttongo.Name = "buttongo";
            this.buttongo.Size = new System.Drawing.Size(231, 73);
            this.buttongo.TabIndex = 29;
            this.buttongo.Text = "Finish";
            this.buttongo.UseVisualStyleBackColor = false;
            this.buttongo.Click += new System.EventHandler(this.buttongo_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.LimeGreen;
            this.button11.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button11.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.ForeColor = System.Drawing.Color.White;
            this.button11.Location = new System.Drawing.Point(4, 683);
            this.button11.Margin = new System.Windows.Forms.Padding(4);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(231, 73);
            this.button11.TabIndex = 35;
            this.button11.Text = "Go Back";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.GoBack_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Female);
            this.groupBox1.Controls.Add(this.Male);
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(246, 460);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(174, 178);
            this.groupBox1.TabIndex = 36;
            this.groupBox1.TabStop = false;
            // 
            // Female
            // 
            this.Female.Font = new System.Drawing.Font("Verdana", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Female.Location = new System.Drawing.Point(6, 94);
            this.Female.Name = "Female";
            this.Female.Size = new System.Drawing.Size(158, 60);
            this.Female.TabIndex = 1;
            this.Female.TabStop = true;
            this.Female.Text = "Female";
            this.Female.UseVisualStyleBackColor = true;
            // 
            // Male
            // 
            this.Male.Font = new System.Drawing.Font("Verdana", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Male.Location = new System.Drawing.Point(6, 28);
            this.Male.Name = "Male";
            this.Male.Size = new System.Drawing.Size(158, 60);
            this.Male.TabIndex = 0;
            this.Male.TabStop = true;
            this.Male.Text = "Male";
            this.Male.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.widowed);
            this.groupBox2.Controls.Add(this.divorced);
            this.groupBox2.Controls.Add(this.separated);
            this.groupBox2.Controls.Add(this.married);
            this.groupBox2.Controls.Add(this.single);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox2.Font = new System.Drawing.Font("Verdana", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(493, 460);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(426, 199);
            this.groupBox2.TabIndex = 37;
            this.groupBox2.TabStop = false;
            // 
            // widowed
            // 
            this.widowed.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.widowed.FlatAppearance.CheckedBackColor = System.Drawing.SystemColors.ControlDark;
            this.widowed.Font = new System.Drawing.Font("Verdana", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.widowed.Location = new System.Drawing.Point(206, 145);
            this.widowed.Name = "widowed";
            this.widowed.Size = new System.Drawing.Size(198, 60);
            this.widowed.TabIndex = 3;
            this.widowed.TabStop = true;
            this.widowed.Text = "Widowed";
            this.widowed.UseVisualStyleBackColor = true;
            // 
            // divorced
            // 
            this.divorced.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.divorced.FlatAppearance.CheckedBackColor = System.Drawing.SystemColors.ControlDark;
            this.divorced.Font = new System.Drawing.Font("Verdana", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.divorced.Location = new System.Drawing.Point(206, 85);
            this.divorced.Name = "divorced";
            this.divorced.Size = new System.Drawing.Size(198, 60);
            this.divorced.TabIndex = 3;
            this.divorced.TabStop = true;
            this.divorced.Text = "Divorced";
            this.divorced.UseVisualStyleBackColor = true;
            // 
            // separated
            // 
            this.separated.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.separated.FlatAppearance.CheckedBackColor = System.Drawing.SystemColors.ControlDark;
            this.separated.Font = new System.Drawing.Font("Verdana", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.separated.Location = new System.Drawing.Point(206, 28);
            this.separated.Name = "separated";
            this.separated.Size = new System.Drawing.Size(198, 60);
            this.separated.TabIndex = 2;
            this.separated.TabStop = true;
            this.separated.Text = "Separated";
            this.separated.UseVisualStyleBackColor = true;
            // 
            // married
            // 
            this.married.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.married.FlatAppearance.CheckedBackColor = System.Drawing.SystemColors.ControlDark;
            this.married.Font = new System.Drawing.Font("Verdana", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.married.Location = new System.Drawing.Point(6, 86);
            this.married.Name = "married";
            this.married.Size = new System.Drawing.Size(164, 60);
            this.married.TabIndex = 1;
            this.married.TabStop = true;
            this.married.Text = "Married";
            this.married.UseVisualStyleBackColor = true;
            // 
            // single
            // 
            this.single.BackColor = System.Drawing.SystemColors.Control;
            this.single.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.single.FlatAppearance.CheckedBackColor = System.Drawing.SystemColors.ControlDark;
            this.single.Font = new System.Drawing.Font("Verdana", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.single.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.single.Location = new System.Drawing.Point(6, 28);
            this.single.Name = "single";
            this.single.Size = new System.Drawing.Size(164, 60);
            this.single.TabIndex = 0;
            this.single.TabStop = true;
            this.single.Text = "Single";
            this.single.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.single.UseVisualStyleBackColor = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Firebrick;
            this.label9.Location = new System.Drawing.Point(77, -29);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 26);
            this.label9.TabIndex = 51;
            this.label9.Text = "label1";
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label13.Location = new System.Drawing.Point(-57, -29);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(99, 26);
            this.label13.TabIndex = 52;
            this.label13.Text = "Address";
            this.label13.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // first
            // 
            this.first.AutoSize = true;
            this.first.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.first.ForeColor = System.Drawing.Color.Firebrick;
            this.first.Location = new System.Drawing.Point(162, 16);
            this.first.Name = "first";
            this.first.Size = new System.Drawing.Size(78, 26);
            this.first.TabIndex = 38;
            this.first.Text = "label1";
            // 
            // goesby
            // 
            this.goesby.AutoSize = true;
            this.goesby.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.goesby.ForeColor = System.Drawing.Color.Firebrick;
            this.goesby.Location = new System.Drawing.Point(162, 50);
            this.goesby.Name = "goesby";
            this.goesby.Size = new System.Drawing.Size(78, 26);
            this.goesby.TabIndex = 39;
            this.goesby.Text = "label1";
            // 
            // last
            // 
            this.last.AutoSize = true;
            this.last.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.last.ForeColor = System.Drawing.Color.Firebrick;
            this.last.Location = new System.Drawing.Point(162, 84);
            this.last.Name = "last";
            this.last.Size = new System.Drawing.Size(78, 26);
            this.last.TabIndex = 40;
            this.last.Text = "label1";
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.ForeColor = System.Drawing.Color.Firebrick;
            this.email.Location = new System.Drawing.Point(162, 118);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(78, 26);
            this.email.TabIndex = 41;
            this.email.Text = "label1";
            // 
            // dob
            // 
            this.dob.AutoSize = true;
            this.dob.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dob.ForeColor = System.Drawing.Color.Firebrick;
            this.dob.Location = new System.Drawing.Point(781, 18);
            this.dob.Name = "dob";
            this.dob.Size = new System.Drawing.Size(78, 26);
            this.dob.TabIndex = 42;
            this.dob.Text = "label1";
            // 
            // cellphone
            // 
            this.cellphone.AutoSize = true;
            this.cellphone.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cellphone.ForeColor = System.Drawing.Color.Firebrick;
            this.cellphone.Location = new System.Drawing.Point(781, 86);
            this.cellphone.Name = "cellphone";
            this.cellphone.Size = new System.Drawing.Size(78, 26);
            this.cellphone.TabIndex = 42;
            this.cellphone.Text = "label1";
            // 
            // homephone
            // 
            this.homephone.AutoSize = true;
            this.homephone.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homephone.ForeColor = System.Drawing.Color.Firebrick;
            this.homephone.Location = new System.Drawing.Point(781, 52);
            this.homephone.Name = "homephone";
            this.homephone.Size = new System.Drawing.Size(78, 26);
            this.homephone.TabIndex = 42;
            this.homephone.Text = "label1";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label1.Location = new System.Drawing.Point(677, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 26);
            this.label1.TabIndex = 47;
            this.label1.Text = "Home";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label2.Location = new System.Drawing.Point(704, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 26);
            this.label2.TabIndex = 48;
            this.label2.Text = "Cell";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label3.Location = new System.Drawing.Point(639, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 26);
            this.label3.TabIndex = 49;
            this.label3.Text = "Birthday";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label4.Location = new System.Drawing.Point(60, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 26);
            this.label4.TabIndex = 46;
            this.label4.Text = "Email";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label5.Location = new System.Drawing.Point(81, 84);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 26);
            this.label5.TabIndex = 45;
            this.label5.Text = "Last";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label6.Location = new System.Drawing.Point(25, 50);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 26);
            this.label6.TabIndex = 44;
            this.label6.Text = "Goes by";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label7.Location = new System.Drawing.Point(77, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 26);
            this.label7.TabIndex = 43;
            this.label7.Text = "First";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label8.Location = new System.Drawing.Point(28, 160);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(99, 26);
            this.label8.TabIndex = 52;
            this.label8.Text = "Address";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // addr
            // 
            this.addr.AutoSize = true;
            this.addr.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addr.ForeColor = System.Drawing.Color.Firebrick;
            this.addr.Location = new System.Drawing.Point(162, 160);
            this.addr.Name = "addr";
            this.addr.Size = new System.Drawing.Size(78, 26);
            this.addr.TabIndex = 51;
            this.addr.Text = "label1";
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label10.Location = new System.Drawing.Point(714, 160);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 26);
            this.label10.TabIndex = 54;
            this.label10.Text = "Zip";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // zip
            // 
            this.zip.AutoSize = true;
            this.zip.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zip.ForeColor = System.Drawing.Color.Firebrick;
            this.zip.Location = new System.Drawing.Point(781, 160);
            this.zip.Name = "zip";
            this.zip.Size = new System.Drawing.Size(78, 26);
            this.zip.TabIndex = 53;
            this.zip.Text = "label1";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LimeGreen;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(372, 683);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(231, 73);
            this.button1.TabIndex = 55;
            this.button1.Text = "Cancel";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // allergies
            // 
            this.allergies.AutoSize = true;
            this.allergies.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.allergies.ForeColor = System.Drawing.Color.Firebrick;
            this.allergies.Location = new System.Drawing.Point(162, 207);
            this.allergies.Name = "allergies";
            this.allergies.Size = new System.Drawing.Size(0, 26);
            this.allergies.TabIndex = 56;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label11.Location = new System.Drawing.Point(16, 207);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(105, 26);
            this.label11.TabIndex = 57;
            this.label11.Text = "Allergies";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // emfriendlab
            // 
            this.emfriendlab.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.emfriendlab.AutoSize = true;
            this.emfriendlab.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emfriendlab.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.emfriendlab.Location = new System.Drawing.Point(51, 317);
            this.emfriendlab.Name = "emfriendlab";
            this.emfriendlab.Size = new System.Drawing.Size(81, 26);
            this.emfriendlab.TabIndex = 58;
            this.emfriendlab.Text = "Friend";
            this.emfriendlab.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // emphonelab
            // 
            this.emphonelab.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.emphonelab.AutoSize = true;
            this.emphonelab.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emphonelab.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.emphonelab.Location = new System.Drawing.Point(51, 351);
            this.emphonelab.Name = "emphonelab";
            this.emphonelab.Size = new System.Drawing.Size(79, 26);
            this.emphonelab.TabIndex = 59;
            this.emphonelab.Text = "Phone";
            this.emphonelab.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // EmFriend
            // 
            this.EmFriend.AutoSize = true;
            this.EmFriend.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmFriend.ForeColor = System.Drawing.Color.Firebrick;
            this.EmFriend.Location = new System.Drawing.Point(160, 317);
            this.EmFriend.Name = "EmFriend";
            this.EmFriend.Size = new System.Drawing.Size(0, 26);
            this.EmFriend.TabIndex = 60;
            // 
            // EmPhone
            // 
            this.EmPhone.AutoSize = true;
            this.EmPhone.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmPhone.ForeColor = System.Drawing.Color.Firebrick;
            this.EmPhone.Location = new System.Drawing.Point(160, 351);
            this.EmPhone.Name = "EmPhone";
            this.EmPhone.Size = new System.Drawing.Size(0, 26);
            this.EmPhone.TabIndex = 61;
            // 
            // emergencylab
            // 
            this.emergencylab.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.emergencylab.AutoSize = true;
            this.emergencylab.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emergencylab.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.emergencylab.Location = new System.Drawing.Point(17, 258);
            this.emergencylab.Name = "emergencylab";
            this.emergencylab.Size = new System.Drawing.Size(106, 18);
            this.emergencylab.TabIndex = 62;
            this.emergencylab.Text = "Emergency";
            this.emergencylab.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // grade
            // 
            this.grade.AutoSize = true;
            this.grade.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grade.ForeColor = System.Drawing.Color.Firebrick;
            this.grade.Location = new System.Drawing.Point(779, 314);
            this.grade.Name = "grade";
            this.grade.Size = new System.Drawing.Size(0, 26);
            this.grade.TabIndex = 42;
            // 
            // gradelab
            // 
            this.gradelab.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gradelab.AutoSize = true;
            this.gradelab.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gradelab.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.gradelab.Location = new System.Drawing.Point(672, 314);
            this.gradelab.Name = "gradelab";
            this.gradelab.Size = new System.Drawing.Size(78, 26);
            this.gradelab.TabIndex = 49;
            this.gradelab.Text = "Grade";
            this.gradelab.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // ActiveOther
            // 
            this.ActiveOther.AutoSize = true;
            this.ActiveOther.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ActiveOther.Checked = true;
            this.ActiveOther.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.ActiveOther.Font = new System.Drawing.Font("Verdana", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ActiveOther.Location = new System.Drawing.Point(14, 431);
            this.ActiveOther.Name = "ActiveOther";
            this.ActiveOther.Size = new System.Drawing.Size(324, 36);
            this.ActiveOther.TabIndex = 63;
            this.ActiveOther.Text = "Active Other Church?";
            this.ActiveOther.ThreeState = true;
            this.ActiveOther.UseVisualStyleBackColor = true;
            // 
            // ParentName
            // 
            this.ParentName.AutoSize = true;
            this.ParentName.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ParentName.ForeColor = System.Drawing.Color.Firebrick;
            this.ParentName.Location = new System.Drawing.Point(160, 283);
            this.ParentName.Name = "ParentName";
            this.ParentName.Size = new System.Drawing.Size(0, 26);
            this.ParentName.TabIndex = 65;
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label12.Location = new System.Drawing.Point(48, 283);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(83, 26);
            this.label12.TabIndex = 64;
            this.label12.Text = "Parent";
            this.label12.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // churchnameLab
            // 
            this.churchnameLab.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.churchnameLab.AutoSize = true;
            this.churchnameLab.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.churchnameLab.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.churchnameLab.Location = new System.Drawing.Point(37, 394);
            this.churchnameLab.Name = "churchnameLab";
            this.churchnameLab.Size = new System.Drawing.Size(89, 26);
            this.churchnameLab.TabIndex = 67;
            this.churchnameLab.Text = "Church";
            this.churchnameLab.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // churchname
            // 
            this.churchname.AutoSize = true;
            this.churchname.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.churchname.ForeColor = System.Drawing.Color.Firebrick;
            this.churchname.Location = new System.Drawing.Point(162, 394);
            this.churchname.Name = "churchname";
            this.churchname.Size = new System.Drawing.Size(0, 26);
            this.churchname.TabIndex = 66;
            // 
            // EnterGenderMarital
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.churchnameLab);
            this.Controls.Add(this.churchname);
            this.Controls.Add(this.ParentName);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.ActiveOther);
            this.Controls.Add(this.emergencylab);
            this.Controls.Add(this.EmPhone);
            this.Controls.Add(this.EmFriend);
            this.Controls.Add(this.emphonelab);
            this.Controls.Add(this.emfriendlab);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.allergies);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.zip);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.addr);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.gradelab);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.homephone);
            this.Controls.Add(this.cellphone);
            this.Controls.Add(this.grade);
            this.Controls.Add(this.dob);
            this.Controls.Add(this.email);
            this.Controls.Add(this.last);
            this.Controls.Add(this.goesby);
            this.Controls.Add(this.first);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.buttongo);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "EnterGenderMarital";
            this.Size = new System.Drawing.Size(1024, 768);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttongo;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton Female;
        private System.Windows.Forms.RadioButton Male;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton widowed;
        private System.Windows.Forms.RadioButton divorced;
        private System.Windows.Forms.RadioButton separated;
        private System.Windows.Forms.RadioButton married;
        private System.Windows.Forms.RadioButton single;
        private System.Windows.Forms.Label first;
        private System.Windows.Forms.Label goesby;
        private System.Windows.Forms.Label last;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.Label dob;
        private System.Windows.Forms.Label cellphone;
        private System.Windows.Forms.Label homephone;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label addr;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label zip;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label allergies;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label emfriendlab;
        private System.Windows.Forms.Label emphonelab;
        private System.Windows.Forms.Label EmFriend;
        private System.Windows.Forms.Label EmPhone;
        private System.Windows.Forms.Label emergencylab;
        private System.Windows.Forms.Label grade;
        private System.Windows.Forms.Label gradelab;
        private System.Windows.Forms.Label ParentName;
        private System.Windows.Forms.Label label12;
        public System.Windows.Forms.CheckBox ActiveOther;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label churchnameLab;
        private System.Windows.Forms.Label churchname;
    }
}
