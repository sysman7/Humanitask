﻿using System.Windows.Forms;

namespace CmsCheckin
{
	public partial class BuildingAddGuests : Form
	{
		public BuildingAddGuests()
		{
			InitializeComponent();
		}
	}
}
