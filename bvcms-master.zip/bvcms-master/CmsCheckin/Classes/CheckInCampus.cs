﻿namespace CmsCheckin
{
	public class CheckInCampus
	{
		public string id = "";
		public string name = "";

		public string Name
		{
			get { return name; }
		}

		public string ID
		{
			get { return id; }
		}
	}
}