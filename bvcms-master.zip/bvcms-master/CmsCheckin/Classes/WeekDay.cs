﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CmsCheckin
{
	public class WeekDay
	{
		public string id = "";
		public string name = "";

		public string Name
		{
			get { return name; }
		}

		public string ID
		{
			get { return id; }
		}
	}
}
