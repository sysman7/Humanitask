﻿using System.Collections.Generic;

namespace CmsCheckin
{
	public class CheckInInformation
	{
		public List<CheckInSettingsEntry> settings;
		public List<CheckInCampus> campuses;
	}
}