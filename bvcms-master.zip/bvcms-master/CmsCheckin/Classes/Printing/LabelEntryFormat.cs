﻿namespace CmsCheckin.Classes
{
	class LabelEntryFormat : LabelEntryBase
	{
	}
}
