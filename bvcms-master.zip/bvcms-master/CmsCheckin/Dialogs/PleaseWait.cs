using System.Windows.Forms;

namespace CmsCheckin
{
    public partial class PleaseWait : Form
    {
        public PleaseWait()
        {
            InitializeComponent();
        }
    }
}
