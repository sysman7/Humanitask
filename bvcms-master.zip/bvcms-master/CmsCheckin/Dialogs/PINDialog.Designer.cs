﻿namespace CmsCheckin.Dialogs
{
    partial class PINDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.N1 = new System.Windows.Forms.Button();
            this.PIN = new System.Windows.Forms.TextBox();
            this.N2 = new System.Windows.Forms.Button();
            this.N3 = new System.Windows.Forms.Button();
            this.N4 = new System.Windows.Forms.Button();
            this.N5 = new System.Windows.Forms.Button();
            this.N6 = new System.Windows.Forms.Button();
            this.N7 = new System.Windows.Forms.Button();
            this.N8 = new System.Windows.Forms.Button();
            this.N9 = new System.Windows.Forms.Button();
            this.N0 = new System.Windows.Forms.Button();
            this.Back = new System.Windows.Forms.Button();
            this.Go = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // N1
            // 
            this.N1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N1.Location = new System.Drawing.Point(12, 83);
            this.N1.Name = "N1";
            this.N1.Size = new System.Drawing.Size(120, 80);
            this.N1.TabIndex = 1;
            this.N1.Text = "1";
            this.N1.UseVisualStyleBackColor = true;
            // 
            // PIN
            // 
            this.PIN.AcceptsReturn = true;
            this.PIN.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PIN.Location = new System.Drawing.Point(12, 20);
            this.PIN.Name = "PIN";
            this.PIN.PasswordChar = '*';
            this.PIN.Size = new System.Drawing.Size(372, 44);
            this.PIN.TabIndex = 0;
            this.PIN.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.PIN.UseSystemPasswordChar = true;
            this.PIN.WordWrap = false;
            // 
            // N2
            // 
            this.N2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N2.Location = new System.Drawing.Point(138, 83);
            this.N2.Name = "N2";
            this.N2.Size = new System.Drawing.Size(120, 80);
            this.N2.TabIndex = 2;
            this.N2.Text = "2";
            this.N2.UseVisualStyleBackColor = true;
            // 
            // N3
            // 
            this.N3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N3.Location = new System.Drawing.Point(264, 83);
            this.N3.Name = "N3";
            this.N3.Size = new System.Drawing.Size(120, 80);
            this.N3.TabIndex = 3;
            this.N3.Text = "3";
            this.N3.UseVisualStyleBackColor = true;
            // 
            // N4
            // 
            this.N4.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N4.Location = new System.Drawing.Point(12, 169);
            this.N4.Name = "N4";
            this.N4.Size = new System.Drawing.Size(120, 80);
            this.N4.TabIndex = 4;
            this.N4.Text = "4";
            this.N4.UseVisualStyleBackColor = true;
            // 
            // N5
            // 
            this.N5.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N5.Location = new System.Drawing.Point(138, 169);
            this.N5.Name = "N5";
            this.N5.Size = new System.Drawing.Size(120, 80);
            this.N5.TabIndex = 5;
            this.N5.Text = "5";
            this.N5.UseVisualStyleBackColor = true;
            // 
            // N6
            // 
            this.N6.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N6.Location = new System.Drawing.Point(264, 169);
            this.N6.Name = "N6";
            this.N6.Size = new System.Drawing.Size(120, 80);
            this.N6.TabIndex = 6;
            this.N6.Text = "6";
            this.N6.UseVisualStyleBackColor = true;
            // 
            // N7
            // 
            this.N7.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N7.Location = new System.Drawing.Point(12, 255);
            this.N7.Name = "N7";
            this.N7.Size = new System.Drawing.Size(120, 80);
            this.N7.TabIndex = 7;
            this.N7.Text = "7";
            this.N7.UseVisualStyleBackColor = true;
            // 
            // N8
            // 
            this.N8.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N8.Location = new System.Drawing.Point(138, 255);
            this.N8.Name = "N8";
            this.N8.Size = new System.Drawing.Size(120, 80);
            this.N8.TabIndex = 8;
            this.N8.Text = "8";
            this.N8.UseVisualStyleBackColor = true;
            // 
            // N9
            // 
            this.N9.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N9.Location = new System.Drawing.Point(264, 255);
            this.N9.Name = "N9";
            this.N9.Size = new System.Drawing.Size(120, 80);
            this.N9.TabIndex = 9;
            this.N9.Text = "9";
            this.N9.UseVisualStyleBackColor = true;
            // 
            // N0
            // 
            this.N0.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.N0.Location = new System.Drawing.Point(138, 341);
            this.N0.Name = "N0";
            this.N0.Size = new System.Drawing.Size(120, 80);
            this.N0.TabIndex = 10;
            this.N0.Text = "0";
            this.N0.UseVisualStyleBackColor = true;
            // 
            // Back
            // 
            this.Back.BackColor = System.Drawing.Color.Red;
            this.Back.Font = new System.Drawing.Font("Wingdings", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.Back.Location = new System.Drawing.Point(12, 341);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(120, 80);
            this.Back.TabIndex = 11;
            this.Back.Text = "Õ";
            this.Back.UseVisualStyleBackColor = false;
            // 
            // Go
            // 
            this.Go.BackColor = System.Drawing.Color.Lime;
            this.Go.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Go.Location = new System.Drawing.Point(264, 341);
            this.Go.Name = "Go";
            this.Go.Size = new System.Drawing.Size(120, 80);
            this.Go.TabIndex = 12;
            this.Go.Text = "GO";
            this.Go.UseVisualStyleBackColor = false;
            // 
            // PINDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(398, 434);
            this.Controls.Add(this.Go);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.N0);
            this.Controls.Add(this.N9);
            this.Controls.Add(this.N8);
            this.Controls.Add(this.N7);
            this.Controls.Add(this.N6);
            this.Controls.Add(this.N5);
            this.Controls.Add(this.N4);
            this.Controls.Add(this.N3);
            this.Controls.Add(this.N2);
            this.Controls.Add(this.PIN);
            this.Controls.Add(this.N1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PINDialog";
            this.Text = "Enter Admin PIN";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button N1;
        private System.Windows.Forms.TextBox PIN;
        private System.Windows.Forms.Button N2;
        private System.Windows.Forms.Button N3;
        private System.Windows.Forms.Button N4;
        private System.Windows.Forms.Button N5;
        private System.Windows.Forms.Button N6;
        private System.Windows.Forms.Button N7;
        private System.Windows.Forms.Button N8;
        private System.Windows.Forms.Button N9;
        private System.Windows.Forms.Button N0;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.Button Go;
    }
}