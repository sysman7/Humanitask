﻿namespace CmsCheckin
{
    partial class EnterText
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.bq = new System.Windows.Forms.Button();
            this.bbs = new System.Windows.Forms.Button();
            this.bw = new System.Windows.Forms.Button();
            this.bgo = new System.Windows.Forms.Button();
            this.be = new System.Windows.Forms.Button();
            this.br = new System.Windows.Forms.Button();
            this.bt = new System.Windows.Forms.Button();
            this.by = new System.Windows.Forms.Button();
            this.bu = new System.Windows.Forms.Button();
            this.bo = new System.Windows.Forms.Button();
            this.bi = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.bp = new System.Windows.Forms.Button();
            this.bz = new System.Windows.Forms.Button();
            this.ba = new System.Windows.Forms.Button();
            this.bs = new System.Windows.Forms.Button();
            this.bd = new System.Windows.Forms.Button();
            this.bf = new System.Windows.Forms.Button();
            this.bg = new System.Windows.Forms.Button();
            this.bh = new System.Windows.Forms.Button();
            this.bj = new System.Windows.Forms.Button();
            this.bl = new System.Windows.Forms.Button();
            this.bk = new System.Windows.Forms.Button();
            this.bx = new System.Windows.Forms.Button();
            this.bv = new System.Windows.Forms.Button();
            this.bc = new System.Windows.Forms.Button();
            this.bspace = new System.Windows.Forms.Button();
            this.bm = new System.Windows.Forms.Button();
            this.bn = new System.Windows.Forms.Button();
            this.bb = new System.Windows.Forms.Button();
            this.bat = new System.Windows.Forms.Button();
            this.bdot = new System.Windows.Forms.Button();
            this.GoBackButton = new System.Windows.Forms.Button();
            this.b0 = new System.Windows.Forms.Button();
            this.b1 = new System.Windows.Forms.Button();
            this.b2 = new System.Windows.Forms.Button();
            this.b3 = new System.Windows.Forms.Button();
            this.b4 = new System.Windows.Forms.Button();
            this.b5 = new System.Windows.Forms.Button();
            this.b6 = new System.Windows.Forms.Button();
            this.b7 = new System.Windows.Forms.Button();
            this.b9 = new System.Windows.Forms.Button();
            this.b8 = new System.Windows.Forms.Button();
            this.b_ = new System.Windows.Forms.Button();
            this.bdash = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.bsharp = new System.Windows.Forms.Button();
            this.bcomma = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(68, 119);
            this.textBox1.Margin = new System.Windows.Forms.Padding(8, 4, 4, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(759, 64);
            this.textBox1.TabIndex = 31;
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // bq
            // 
            this.bq.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bq.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bq.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bq.Location = new System.Drawing.Point(33, 282);
            this.bq.Margin = new System.Windows.Forms.Padding(4);
            this.bq.Name = "bq";
            this.bq.Size = new System.Drawing.Size(89, 81);
            this.bq.TabIndex = 16;
            this.bq.Text = "Q";
            this.bq.UseVisualStyleBackColor = false;
            // 
            // bbs
            // 
            this.bbs.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bbs.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bbs.Font = new System.Drawing.Font("Wingdings", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.bbs.Location = new System.Drawing.Point(840, 97);
            this.bbs.Margin = new System.Windows.Forms.Padding(4);
            this.bbs.Name = "bbs";
            this.bbs.Size = new System.Drawing.Size(132, 86);
            this.bbs.TabIndex = 30;
            this.bbs.Text = "Õ";
            this.bbs.UseVisualStyleBackColor = false;
            this.bbs.Click += new System.EventHandler(this.buttonbs_Click);
            // 
            // bw
            // 
            this.bw.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bw.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bw.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bw.Location = new System.Drawing.Point(130, 282);
            this.bw.Margin = new System.Windows.Forms.Padding(4);
            this.bw.Name = "bw";
            this.bw.Size = new System.Drawing.Size(89, 81);
            this.bw.TabIndex = 17;
            this.bw.Text = "W";
            this.bw.UseVisualStyleBackColor = false;
            // 
            // bgo
            // 
            this.bgo.BackColor = System.Drawing.Color.LimeGreen;
            this.bgo.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.bgo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bgo.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bgo.ForeColor = System.Drawing.Color.White;
            this.bgo.Location = new System.Drawing.Point(852, 491);
            this.bgo.Margin = new System.Windows.Forms.Padding(4);
            this.bgo.Name = "bgo";
            this.bgo.Size = new System.Drawing.Size(168, 122);
            this.bgo.TabIndex = 29;
            this.bgo.Text = "Next";
            this.bgo.UseVisualStyleBackColor = false;
            this.bgo.Click += new System.EventHandler(this.buttongo_Click);
            // 
            // be
            // 
            this.be.BackColor = System.Drawing.SystemColors.ControlLight;
            this.be.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.be.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.be.Location = new System.Drawing.Point(227, 282);
            this.be.Margin = new System.Windows.Forms.Padding(4);
            this.be.Name = "be";
            this.be.Size = new System.Drawing.Size(89, 81);
            this.be.TabIndex = 18;
            this.be.Text = "E";
            this.be.UseVisualStyleBackColor = false;
            // 
            // br
            // 
            this.br.BackColor = System.Drawing.SystemColors.ControlLight;
            this.br.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.br.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.br.Location = new System.Drawing.Point(324, 282);
            this.br.Margin = new System.Windows.Forms.Padding(4);
            this.br.Name = "br";
            this.br.Size = new System.Drawing.Size(89, 81);
            this.br.TabIndex = 19;
            this.br.Text = "R";
            this.br.UseVisualStyleBackColor = false;
            // 
            // bt
            // 
            this.bt.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bt.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt.Location = new System.Drawing.Point(421, 282);
            this.bt.Margin = new System.Windows.Forms.Padding(4);
            this.bt.Name = "bt";
            this.bt.Size = new System.Drawing.Size(89, 81);
            this.bt.TabIndex = 20;
            this.bt.Text = "T";
            this.bt.UseVisualStyleBackColor = false;
            // 
            // by
            // 
            this.by.BackColor = System.Drawing.SystemColors.ControlLight;
            this.by.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.by.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.by.Location = new System.Drawing.Point(518, 282);
            this.by.Margin = new System.Windows.Forms.Padding(4);
            this.by.Name = "by";
            this.by.Size = new System.Drawing.Size(89, 81);
            this.by.TabIndex = 21;
            this.by.Text = "Y";
            this.by.UseVisualStyleBackColor = false;
            // 
            // bu
            // 
            this.bu.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bu.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bu.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bu.Location = new System.Drawing.Point(615, 282);
            this.bu.Margin = new System.Windows.Forms.Padding(4);
            this.bu.Name = "bu";
            this.bu.Size = new System.Drawing.Size(89, 81);
            this.bu.TabIndex = 22;
            this.bu.Text = "U";
            this.bu.UseVisualStyleBackColor = false;
            // 
            // bo
            // 
            this.bo.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bo.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bo.Location = new System.Drawing.Point(809, 282);
            this.bo.Margin = new System.Windows.Forms.Padding(4);
            this.bo.Name = "bo";
            this.bo.Size = new System.Drawing.Size(89, 81);
            this.bo.TabIndex = 24;
            this.bo.Text = "O";
            this.bo.UseVisualStyleBackColor = false;
            // 
            // bi
            // 
            this.bi.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bi.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bi.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bi.Location = new System.Drawing.Point(712, 282);
            this.bi.Margin = new System.Windows.Forms.Padding(4);
            this.bi.Name = "bi";
            this.bi.Size = new System.Drawing.Size(89, 81);
            this.bi.TabIndex = 23;
            this.bi.Text = "I";
            this.bi.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Verdana", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.OrangeRed;
            this.label2.Location = new System.Drawing.Point(64, 29);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(763, 73);
            this.label2.TabIndex = 34;
            this.label2.Text = "label";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bp
            // 
            this.bp.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bp.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bp.Location = new System.Drawing.Point(906, 282);
            this.bp.Margin = new System.Windows.Forms.Padding(4);
            this.bp.Name = "bp";
            this.bp.Size = new System.Drawing.Size(89, 81);
            this.bp.TabIndex = 35;
            this.bp.Text = "P";
            this.bp.UseVisualStyleBackColor = false;
            // 
            // bz
            // 
            this.bz.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bz.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bz.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bz.Location = new System.Drawing.Point(131, 461);
            this.bz.Margin = new System.Windows.Forms.Padding(4);
            this.bz.Name = "bz";
            this.bz.Size = new System.Drawing.Size(89, 81);
            this.bz.TabIndex = 45;
            this.bz.Text = "Z";
            this.bz.UseVisualStyleBackColor = false;
            // 
            // ba
            // 
            this.ba.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ba.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ba.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ba.Location = new System.Drawing.Point(64, 371);
            this.ba.Margin = new System.Windows.Forms.Padding(4);
            this.ba.Name = "ba";
            this.ba.Size = new System.Drawing.Size(89, 82);
            this.ba.TabIndex = 36;
            this.ba.Text = "A";
            this.ba.UseVisualStyleBackColor = false;
            // 
            // bs
            // 
            this.bs.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bs.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bs.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bs.Location = new System.Drawing.Point(161, 371);
            this.bs.Margin = new System.Windows.Forms.Padding(4);
            this.bs.Name = "bs";
            this.bs.Size = new System.Drawing.Size(89, 82);
            this.bs.TabIndex = 37;
            this.bs.Text = "S";
            this.bs.UseVisualStyleBackColor = false;
            // 
            // bd
            // 
            this.bd.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bd.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bd.Location = new System.Drawing.Point(258, 371);
            this.bd.Margin = new System.Windows.Forms.Padding(4);
            this.bd.Name = "bd";
            this.bd.Size = new System.Drawing.Size(89, 82);
            this.bd.TabIndex = 38;
            this.bd.Text = "D";
            this.bd.UseVisualStyleBackColor = false;
            // 
            // bf
            // 
            this.bf.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bf.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bf.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bf.Location = new System.Drawing.Point(355, 371);
            this.bf.Margin = new System.Windows.Forms.Padding(4);
            this.bf.Name = "bf";
            this.bf.Size = new System.Drawing.Size(89, 82);
            this.bf.TabIndex = 39;
            this.bf.Text = "F";
            this.bf.UseVisualStyleBackColor = false;
            // 
            // bg
            // 
            this.bg.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bg.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bg.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bg.Location = new System.Drawing.Point(452, 371);
            this.bg.Margin = new System.Windows.Forms.Padding(4);
            this.bg.Name = "bg";
            this.bg.Size = new System.Drawing.Size(89, 82);
            this.bg.TabIndex = 40;
            this.bg.Text = "G";
            this.bg.UseVisualStyleBackColor = false;
            // 
            // bh
            // 
            this.bh.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bh.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bh.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bh.Location = new System.Drawing.Point(549, 371);
            this.bh.Margin = new System.Windows.Forms.Padding(4);
            this.bh.Name = "bh";
            this.bh.Size = new System.Drawing.Size(89, 82);
            this.bh.TabIndex = 41;
            this.bh.Text = "H";
            this.bh.UseVisualStyleBackColor = false;
            // 
            // bj
            // 
            this.bj.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bj.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bj.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bj.Location = new System.Drawing.Point(646, 371);
            this.bj.Margin = new System.Windows.Forms.Padding(4);
            this.bj.Name = "bj";
            this.bj.Size = new System.Drawing.Size(89, 82);
            this.bj.TabIndex = 42;
            this.bj.Text = "J";
            this.bj.UseVisualStyleBackColor = false;
            // 
            // bl
            // 
            this.bl.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bl.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bl.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bl.Location = new System.Drawing.Point(840, 371);
            this.bl.Margin = new System.Windows.Forms.Padding(4);
            this.bl.Name = "bl";
            this.bl.Size = new System.Drawing.Size(89, 82);
            this.bl.TabIndex = 44;
            this.bl.Text = "L";
            this.bl.UseVisualStyleBackColor = false;
            // 
            // bk
            // 
            this.bk.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bk.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bk.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bk.Location = new System.Drawing.Point(743, 371);
            this.bk.Margin = new System.Windows.Forms.Padding(4);
            this.bk.Name = "bk";
            this.bk.Size = new System.Drawing.Size(89, 82);
            this.bk.TabIndex = 43;
            this.bk.Text = "K";
            this.bk.UseVisualStyleBackColor = false;
            // 
            // bx
            // 
            this.bx.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bx.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bx.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bx.Location = new System.Drawing.Point(228, 461);
            this.bx.Margin = new System.Windows.Forms.Padding(4);
            this.bx.Name = "bx";
            this.bx.Size = new System.Drawing.Size(89, 81);
            this.bx.TabIndex = 46;
            this.bx.Text = "X";
            this.bx.UseVisualStyleBackColor = false;
            // 
            // bv
            // 
            this.bv.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bv.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bv.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bv.Location = new System.Drawing.Point(422, 461);
            this.bv.Margin = new System.Windows.Forms.Padding(4);
            this.bv.Name = "bv";
            this.bv.Size = new System.Drawing.Size(89, 81);
            this.bv.TabIndex = 48;
            this.bv.Text = "V";
            this.bv.UseVisualStyleBackColor = false;
            // 
            // bc
            // 
            this.bc.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bc.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bc.Location = new System.Drawing.Point(325, 461);
            this.bc.Margin = new System.Windows.Forms.Padding(4);
            this.bc.Name = "bc";
            this.bc.Size = new System.Drawing.Size(89, 81);
            this.bc.TabIndex = 47;
            this.bc.Text = "C";
            this.bc.UseVisualStyleBackColor = false;
            // 
            // bspace
            // 
            this.bspace.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bspace.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bspace.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bspace.Location = new System.Drawing.Point(204, 550);
            this.bspace.Margin = new System.Windows.Forms.Padding(4);
            this.bspace.Name = "bspace";
            this.bspace.Size = new System.Drawing.Size(315, 85);
            this.bspace.TabIndex = 52;
            this.bspace.Text = "space";
            this.bspace.UseVisualStyleBackColor = false;
            this.bspace.Click += new System.EventHandler(this.bspace_Click);
            // 
            // bm
            // 
            this.bm.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bm.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bm.Location = new System.Drawing.Point(713, 461);
            this.bm.Margin = new System.Windows.Forms.Padding(4);
            this.bm.Name = "bm";
            this.bm.Size = new System.Drawing.Size(89, 81);
            this.bm.TabIndex = 51;
            this.bm.Text = "M";
            this.bm.UseVisualStyleBackColor = false;
            // 
            // bn
            // 
            this.bn.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bn.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bn.Location = new System.Drawing.Point(616, 461);
            this.bn.Margin = new System.Windows.Forms.Padding(4);
            this.bn.Name = "bn";
            this.bn.Size = new System.Drawing.Size(89, 81);
            this.bn.TabIndex = 50;
            this.bn.Text = "N";
            this.bn.UseVisualStyleBackColor = false;
            // 
            // bb
            // 
            this.bb.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bb.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bb.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bb.Location = new System.Drawing.Point(519, 461);
            this.bb.Margin = new System.Windows.Forms.Padding(4);
            this.bb.Name = "bb";
            this.bb.Size = new System.Drawing.Size(89, 81);
            this.bb.TabIndex = 49;
            this.bb.Text = "B";
            this.bb.UseVisualStyleBackColor = false;
            // 
            // bat
            // 
            this.bat.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bat.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bat.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bat.Location = new System.Drawing.Point(527, 643);
            this.bat.Margin = new System.Windows.Forms.Padding(4);
            this.bat.Name = "bat";
            this.bat.Size = new System.Drawing.Size(100, 85);
            this.bat.TabIndex = 53;
            this.bat.Text = "@";
            this.bat.UseVisualStyleBackColor = false;
            this.bat.Click += new System.EventHandler(this.bat_Click);
            // 
            // bdot
            // 
            this.bdot.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bdot.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bdot.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bdot.Location = new System.Drawing.Point(635, 550);
            this.bdot.Margin = new System.Windows.Forms.Padding(4);
            this.bdot.Name = "bdot";
            this.bdot.Size = new System.Drawing.Size(100, 85);
            this.bdot.TabIndex = 54;
            this.bdot.Text = ".";
            this.bdot.UseVisualStyleBackColor = false;
            this.bdot.Click += new System.EventHandler(this.bdot_Click);
            // 
            // GoBackButton
            // 
            this.GoBackButton.BackColor = System.Drawing.Color.LimeGreen;
            this.GoBackButton.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.GoBackButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.GoBackButton.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GoBackButton.ForeColor = System.Drawing.Color.White;
            this.GoBackButton.Location = new System.Drawing.Point(4, 689);
            this.GoBackButton.Margin = new System.Windows.Forms.Padding(4);
            this.GoBackButton.Name = "GoBackButton";
            this.GoBackButton.Size = new System.Drawing.Size(265, 75);
            this.GoBackButton.TabIndex = 55;
            this.GoBackButton.Text = "Go Back";
            this.GoBackButton.UseVisualStyleBackColor = false;
            this.GoBackButton.Click += new System.EventHandler(this.GoBackButton_Click);
            // 
            // b0
            // 
            this.b0.BackColor = System.Drawing.SystemColors.ControlLight;
            this.b0.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.b0.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b0.Location = new System.Drawing.Point(883, 193);
            this.b0.Margin = new System.Windows.Forms.Padding(4);
            this.b0.Name = "b0";
            this.b0.Size = new System.Drawing.Size(89, 81);
            this.b0.TabIndex = 65;
            this.b0.Text = "0";
            this.b0.UseVisualStyleBackColor = false;
            // 
            // b1
            // 
            this.b1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.b1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.b1.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b1.Location = new System.Drawing.Point(10, 193);
            this.b1.Margin = new System.Windows.Forms.Padding(4);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(89, 81);
            this.b1.TabIndex = 56;
            this.b1.Text = "1";
            this.b1.UseVisualStyleBackColor = false;
            // 
            // b2
            // 
            this.b2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.b2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.b2.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b2.Location = new System.Drawing.Point(107, 193);
            this.b2.Margin = new System.Windows.Forms.Padding(4);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(89, 81);
            this.b2.TabIndex = 57;
            this.b2.Text = "2";
            this.b2.UseVisualStyleBackColor = false;
            // 
            // b3
            // 
            this.b3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.b3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.b3.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b3.Location = new System.Drawing.Point(204, 193);
            this.b3.Margin = new System.Windows.Forms.Padding(4);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(89, 81);
            this.b3.TabIndex = 58;
            this.b3.Text = "3";
            this.b3.UseVisualStyleBackColor = false;
            // 
            // b4
            // 
            this.b4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.b4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.b4.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b4.Location = new System.Drawing.Point(301, 193);
            this.b4.Margin = new System.Windows.Forms.Padding(4);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(89, 81);
            this.b4.TabIndex = 59;
            this.b4.Text = "4";
            this.b4.UseVisualStyleBackColor = false;
            // 
            // b5
            // 
            this.b5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.b5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.b5.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b5.Location = new System.Drawing.Point(398, 193);
            this.b5.Margin = new System.Windows.Forms.Padding(4);
            this.b5.Name = "b5";
            this.b5.Size = new System.Drawing.Size(89, 81);
            this.b5.TabIndex = 60;
            this.b5.Text = "5";
            this.b5.UseVisualStyleBackColor = false;
            // 
            // b6
            // 
            this.b6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.b6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.b6.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b6.Location = new System.Drawing.Point(495, 193);
            this.b6.Margin = new System.Windows.Forms.Padding(4);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(89, 81);
            this.b6.TabIndex = 61;
            this.b6.Text = "6";
            this.b6.UseVisualStyleBackColor = false;
            // 
            // b7
            // 
            this.b7.BackColor = System.Drawing.SystemColors.ControlLight;
            this.b7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.b7.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b7.Location = new System.Drawing.Point(592, 193);
            this.b7.Margin = new System.Windows.Forms.Padding(4);
            this.b7.Name = "b7";
            this.b7.Size = new System.Drawing.Size(89, 81);
            this.b7.TabIndex = 62;
            this.b7.Text = "7";
            this.b7.UseVisualStyleBackColor = false;
            // 
            // b9
            // 
            this.b9.BackColor = System.Drawing.SystemColors.ControlLight;
            this.b9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.b9.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b9.Location = new System.Drawing.Point(786, 193);
            this.b9.Margin = new System.Windows.Forms.Padding(4);
            this.b9.Name = "b9";
            this.b9.Size = new System.Drawing.Size(89, 81);
            this.b9.TabIndex = 64;
            this.b9.Text = "9";
            this.b9.UseVisualStyleBackColor = false;
            // 
            // b8
            // 
            this.b8.BackColor = System.Drawing.SystemColors.ControlLight;
            this.b8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.b8.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b8.Location = new System.Drawing.Point(689, 193);
            this.b8.Margin = new System.Windows.Forms.Padding(4);
            this.b8.Name = "b8";
            this.b8.Size = new System.Drawing.Size(89, 81);
            this.b8.TabIndex = 63;
            this.b8.Text = "8";
            this.b8.UseVisualStyleBackColor = false;
            // 
            // b_
            // 
            this.b_.BackColor = System.Drawing.SystemColors.ControlLight;
            this.b_.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.b_.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_.Location = new System.Drawing.Point(743, 643);
            this.b_.Margin = new System.Windows.Forms.Padding(4);
            this.b_.Name = "b_";
            this.b_.Size = new System.Drawing.Size(100, 85);
            this.b_.TabIndex = 66;
            this.b_.Text = "_";
            this.b_.UseVisualStyleBackColor = false;
            // 
            // bdash
            // 
            this.bdash.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bdash.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bdash.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bdash.Location = new System.Drawing.Point(743, 550);
            this.bdash.Margin = new System.Windows.Forms.Padding(4);
            this.bdash.Name = "bdash";
            this.bdash.Size = new System.Drawing.Size(100, 85);
            this.bdash.TabIndex = 67;
            this.bdash.Text = "-";
            this.bdash.UseVisualStyleBackColor = false;
            this.bdash.Click += new System.EventHandler(this.bdash_Click);
            // 
            // clear
            // 
            this.clear.BackColor = System.Drawing.SystemColors.ControlLight;
            this.clear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.clear.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clear.Location = new System.Drawing.Point(840, 3);
            this.clear.Margin = new System.Windows.Forms.Padding(4);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(132, 86);
            this.clear.TabIndex = 68;
            this.clear.Text = "clear";
            this.clear.UseVisualStyleBackColor = false;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // bsharp
            // 
            this.bsharp.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bsharp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bsharp.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bsharp.Location = new System.Drawing.Point(635, 643);
            this.bsharp.Margin = new System.Windows.Forms.Padding(4);
            this.bsharp.Name = "bsharp";
            this.bsharp.Size = new System.Drawing.Size(100, 85);
            this.bsharp.TabIndex = 69;
            this.bsharp.Text = "#";
            this.bsharp.UseVisualStyleBackColor = false;
            this.bsharp.Click += new System.EventHandler(this.bsharp_Click);
            // 
            // bcomma
            // 
            this.bcomma.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bcomma.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bcomma.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bcomma.Location = new System.Drawing.Point(527, 550);
            this.bcomma.Margin = new System.Windows.Forms.Padding(4);
            this.bcomma.Name = "bcomma";
            this.bcomma.Size = new System.Drawing.Size(100, 85);
            this.bcomma.TabIndex = 70;
            this.bcomma.Text = ",";
            this.bcomma.UseVisualStyleBackColor = false;
            this.bcomma.Click += new System.EventHandler(this.bcomma_Click);
            // 
            // EnterText
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.bcomma);
            this.Controls.Add(this.bsharp);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.bdash);
            this.Controls.Add(this.b_);
            this.Controls.Add(this.b0);
            this.Controls.Add(this.b1);
            this.Controls.Add(this.b2);
            this.Controls.Add(this.b3);
            this.Controls.Add(this.b4);
            this.Controls.Add(this.b5);
            this.Controls.Add(this.b6);
            this.Controls.Add(this.b7);
            this.Controls.Add(this.b9);
            this.Controls.Add(this.b8);
            this.Controls.Add(this.GoBackButton);
            this.Controls.Add(this.bdot);
            this.Controls.Add(this.bat);
            this.Controls.Add(this.bspace);
            this.Controls.Add(this.bm);
            this.Controls.Add(this.bn);
            this.Controls.Add(this.bb);
            this.Controls.Add(this.bv);
            this.Controls.Add(this.bc);
            this.Controls.Add(this.bx);
            this.Controls.Add(this.bz);
            this.Controls.Add(this.ba);
            this.Controls.Add(this.bs);
            this.Controls.Add(this.bd);
            this.Controls.Add(this.bf);
            this.Controls.Add(this.bg);
            this.Controls.Add(this.bh);
            this.Controls.Add(this.bj);
            this.Controls.Add(this.bl);
            this.Controls.Add(this.bk);
            this.Controls.Add(this.bp);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.bq);
            this.Controls.Add(this.bbs);
            this.Controls.Add(this.bw);
            this.Controls.Add(this.bgo);
            this.Controls.Add(this.be);
            this.Controls.Add(this.br);
            this.Controls.Add(this.bt);
            this.Controls.Add(this.by);
            this.Controls.Add(this.bu);
            this.Controls.Add(this.bo);
            this.Controls.Add(this.bi);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "EnterText";
            this.Size = new System.Drawing.Size(1024, 768);
            this.Load += new System.EventHandler(this.Name_Load);
            this.VisibleChanged += new System.EventHandler(this.EnterText_VisibleChanged);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bq;
        private System.Windows.Forms.Button bbs;
        private System.Windows.Forms.Button bw;
        private System.Windows.Forms.Button bgo;
        private System.Windows.Forms.Button be;
        private System.Windows.Forms.Button br;
        private System.Windows.Forms.Button bt;
        private System.Windows.Forms.Button by;
        private System.Windows.Forms.Button bu;
        private System.Windows.Forms.Button bo;
        private System.Windows.Forms.Button bi;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button bp;
        private System.Windows.Forms.Button bz;
        private System.Windows.Forms.Button ba;
        private System.Windows.Forms.Button bs;
        private System.Windows.Forms.Button bd;
        private System.Windows.Forms.Button bf;
        private System.Windows.Forms.Button bg;
        private System.Windows.Forms.Button bh;
        private System.Windows.Forms.Button bj;
        private System.Windows.Forms.Button bl;
        private System.Windows.Forms.Button bk;
        private System.Windows.Forms.Button bx;
        private System.Windows.Forms.Button bv;
        private System.Windows.Forms.Button bc;
        private System.Windows.Forms.Button bspace;
        private System.Windows.Forms.Button bm;
        private System.Windows.Forms.Button bn;
        private System.Windows.Forms.Button bb;
        private System.Windows.Forms.Button bat;
        private System.Windows.Forms.Button bdot;
        private System.Windows.Forms.Button GoBackButton;
        private System.Windows.Forms.Button b0;
        private System.Windows.Forms.Button b1;
        private System.Windows.Forms.Button b2;
        private System.Windows.Forms.Button b3;
        private System.Windows.Forms.Button b4;
        private System.Windows.Forms.Button b5;
        private System.Windows.Forms.Button b6;
        private System.Windows.Forms.Button b7;
        private System.Windows.Forms.Button b9;
        private System.Windows.Forms.Button b8;
        private System.Windows.Forms.Button b_;
        private System.Windows.Forms.Button bdash;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.Button bsharp;
        private System.Windows.Forms.Button bcomma;
    }
}
