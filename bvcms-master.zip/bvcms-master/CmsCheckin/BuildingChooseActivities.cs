﻿using System.Windows.Forms;

namespace CmsCheckin
{
	public partial class BuildingChooseActivities : Form
	{
		public BuildingChooseActivities()
		{
			InitializeComponent();
		}
	}
}
